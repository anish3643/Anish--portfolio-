
import React from "react";

export default function Portfolio() {
  return (
    <div className="font-sans bg-white text-gray-900">
      {/* Header */}
      <header className="bg-blue-900 text-white p-6 shadow-md">
        <div className="max-w-4xl mx-auto">
          <h1 className="text-3xl font-bold">Anish Kumar</h1>
          <p className="text-lg">Frontend Developer | Electronics & Communication Engineering Student</p>
          <p className="mt-2">Bangalore, Karnataka 562157</p>
          <p>Phone: +91-6200658427 | Email: mishraanish063@gmail.com</p>
          <a href="https://linkedin.com/in/AnishKumar" className="underline text-blue-300">LinkedIn</a>
        </div>
      </header>

      {/* About Me */}
      <section className="max-w-4xl mx-auto px-6 py-10">
        <h2 className="text-2xl font-bold mb-4">About Me</h2>
        <p>
          I'm a final year Electronics and Communication Engineering student at Sri Venkateshwara College of Engineering, Bangalore, with a passion for web development and AI-based projects. I enjoy building responsive, user-friendly web applications and working with emerging tech like NLP and robotics.
        </p>
      </section>

      {/* Projects */}
      <section className="bg-gray-100 px-6 py-10">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-2xl font-bold mb-4">Projects</h2>
          <div className="bg-white p-4 rounded shadow">
            <h3 className="text-xl font-semibold">AI-Powered Humanoid Robot</h3>
            <p>
              A robot designed to assist with campus navigation and scheduling using GPS and NLP frameworks like TensorFlow and spaCy. Built with Python and Node.js, integrated with robotic hardware for efficient task execution.
            </p>
          </div>
        </div>
      </section>

      {/* Skills */}
      <section className="max-w-4xl mx-auto px-6 py-10">
        <h2 className="text-2xl font-bold mb-4">Technical Skills</h2>
        <ul className="list-disc ml-6">
          <li><strong>Languages:</strong> HTML, CSS, JavaScript, Documentation, Data Analysis</li>
          <li><strong>Technologies/Frameworks:</strong> React, Angular, Bootstrap</li>
          <li><strong>Design Tools:</strong> Figma, Adobe XD</li>
          <li><strong>Version Control:</strong> GitHub</li>
        </ul>
      </section>

      {/* Certifications */}
      <section className="bg-gray-100 px-6 py-10">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-2xl font-bold mb-4">Certifications</h2>
          <ul className="list-disc ml-6">
            <li>IR4.0 Foundation Course by Techsaksham (Microsoft + SAP)</li>
            <li>Frontend Development with React – Infosys Springboard</li>
          </ul>
        </div>
      </section>

      {/* Achievements */}
      <section className="max-w-4xl mx-auto px-6 py-10">
        <h2 className="text-2xl font-bold mb-4">Achievements</h2>
        <ul className="list-disc ml-6">
          <li>Participant, National Level Social Hackathon 2024 – CMRIT College, Bangalore</li>
        </ul>
      </section>

      {/* Education */}
      <section className="bg-gray-100 px-6 py-10">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-2xl font-bold mb-4">Education</h2>
          <ul className="list-disc ml-6">
            <li><strong>Sri Venkateshwara College of Engineering</strong> (Bangalore) – CGPA: 7.5 (Since 2021)</li>
            <li><strong>KC Mount Fort School</strong> (Muzaffarpur) – Intermediate, 65%</li>
            <li><strong>DAV Public School</strong> (Muzaffarpur) – Matriculation, 70%</li>
          </ul>
        </div>
      </section>

      {/* Footer */}
      <footer className="text-center text-sm text-gray-500 p-6">
        <p>&copy; {new Date().getFullYear()} Anish Kumar. All rights reserved.</p>
      </footer>
    </div>
  );
}
